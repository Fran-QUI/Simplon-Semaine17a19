Votre mission sera de réaliser une nouvelle application Rails, qui devra comporter les éléments suivants.

    Ce sera un blog qui aura des articles.
    Chaque article a un titre et un contenu.
    Faites une page d’accueil qui liste les liens des articles.
    Ne faites pas de formulaire mais ajoutez trois articles via la console rails.

Vous serez évalués sur :

    Le respect des fonctionnalités (9 points)
    Le respect des conventions de nommage (11 points)

Zippez votre répertoire, et envoyez-le pour correction !

Bon courage

La page principale est mrbigyblog